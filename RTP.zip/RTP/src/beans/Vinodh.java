package beans;

public class Vinodh {
	public static void main(String[] args) {
		try {
			Phone p = (Phone) Class.forName(args[0]).newInstance();// Phone implementation class
			p.calling();
			Sim s = (Sim) Class.forName(args[1]).newInstance();// Phone implementation class
			s.connectCall();

		} catch (Exception e) {
		}

	}

}
