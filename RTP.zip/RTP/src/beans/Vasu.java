package beans;

public class Vasu {
	public static void main(String[] args) {
		Iphone p = new Iphone();
		p.calling();

		Jio j = new Jio();
		j.connectCall();

	}
}
