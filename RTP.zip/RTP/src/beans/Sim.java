package beans;

public interface Sim {
public void connectCall();
}
