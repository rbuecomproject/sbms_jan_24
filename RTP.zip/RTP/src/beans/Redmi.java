package beans;

public class Redmi implements Phone {
	@Override
	public void calling() {
		System.out.println("calling from redmi");

	}
	
}
