package beans;

public class Iphone implements Phone {
	@Override
	public void calling() {
		System.out.println("calling from IPhone");

	}
}
