package beans;

public interface Phone {
public void calling();
}
