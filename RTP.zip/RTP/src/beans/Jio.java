package beans;

public class Jio implements Sim{
	
	@Override
	public void connectCall() {
	System.out.println("jio connecting to calls");
		
	}

}
