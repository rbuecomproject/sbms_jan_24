package beans;

public class Airtel implements Sim{
	
	@Override
	public void connectCall() {
	System.out.println("Airtel connecting to calls");
		
	}

}
