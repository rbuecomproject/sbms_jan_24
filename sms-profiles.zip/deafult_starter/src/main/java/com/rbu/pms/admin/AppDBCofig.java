package com.rbu.pms.admin;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "database")
public class AppDBCofig {
//	@Value("${key}")
private String url;
private String username;
private String password;
Logger logger = LoggerFactory.getLogger(AppDBCofig.class);

public String getUrl() {
	return url;
}

public void setUrl(String url) {
	this.url = url;
}

public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

@Bean
public Date createDBDate() {
	
	logger.info("createDBDate method started executon");
	System.out.println(url);
	System.out.println(username);
	System.out.println(password);
	logger.info("createDate method completed executon");
	
	return new Date();
} 

}
