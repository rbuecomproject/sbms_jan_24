package com.rbu.pms.admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeafultStarterApplicationTests {

	@Test
	void contextLoads() {
	}

}
