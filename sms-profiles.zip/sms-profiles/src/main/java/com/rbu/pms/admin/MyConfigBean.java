package com.rbu.pms.admin;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile("sit")
public class MyConfigBean {
public MyConfigBean() {
System.out.println("only for SIT");
}
}
