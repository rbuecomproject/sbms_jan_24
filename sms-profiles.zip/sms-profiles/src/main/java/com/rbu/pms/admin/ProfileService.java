package com.rbu.pms.admin;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class ProfileService {
	@Value("${message}")
	private String message;
	@Value("${hai}")
	private String hai;

	public void printData() {
		System.out.println(message);
		System.out.println(hai);
	}

}
