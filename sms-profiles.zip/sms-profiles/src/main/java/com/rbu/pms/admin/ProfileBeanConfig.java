package com.rbu.pms.admin;

import java.util.Calendar;
import java.util.Date;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
public class ProfileBeanConfig {

	@Profile("sit")
	@Bean
	public Date createSitDate() {
		System.out.println("SIT date");
		Date date = new Date();
		return date;
	}

	@Profile("uat")
	@Bean
	public Date createUatDate() {
		System.out.println("UAT date");
		Date date = Calendar.getInstance().getTime();
		return date;
	}

	@Profile("prod")
	@Bean
	public Date createProdDate() {
		System.out.println("PROD date");
		Date date = Calendar.getInstance().getTime();
		return date;
	}

	@Profile("dev")
	@Bean
	public Date createDevDate() {
		System.out.println("dev date");
		Date date = new Date(2024, 03, 12);
		return date;
	}

}
