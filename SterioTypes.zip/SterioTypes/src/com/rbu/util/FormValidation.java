package com.rbu.util;

import org.springframework.stereotype.Component;

@Component
public class FormValidation {

	public FormValidation() {
	System.out.println("FormValidation - object");
	}
	
}
