package com.rbu.config;

import java.sql.Connection;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DBConfig {

	public DBConfig() {
	System.out.println("DBConfig - object");
	}
	
	@Bean
	public Connection createCon() {
		System.out.println("Connection-object");
		return null;
	}
}
