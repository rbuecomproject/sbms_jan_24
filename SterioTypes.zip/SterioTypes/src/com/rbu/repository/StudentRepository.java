package com.rbu.repository;

import org.springframework.stereotype.Repository;

@Repository
public class StudentRepository {
	
	
	public StudentRepository() {
	System.out.println("StudentRepository - object");
	}

}
