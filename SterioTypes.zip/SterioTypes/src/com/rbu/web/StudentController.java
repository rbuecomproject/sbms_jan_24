package com.rbu.web;

import org.springframework.stereotype.Controller;

@Controller
public class StudentController {
	
	
	public StudentController() {
	System.out.println("StudentController - object");
	}

}
