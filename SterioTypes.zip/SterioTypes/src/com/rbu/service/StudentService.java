package com.rbu.service;

import org.springframework.stereotype.Service;

@Service
public class StudentService {
	
	
	public StudentService() {
	System.out.println("StudentService - object");
	}

}
