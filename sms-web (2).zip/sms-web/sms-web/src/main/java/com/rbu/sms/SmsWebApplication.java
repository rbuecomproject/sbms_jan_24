package com.rbu.sms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmsWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmsWebApplication.class, args);
		//start IOC
		//start Tomcat
		// defult DispatcherServelet will initilize
	}

}
