package ioc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.rbu.sms.business.StudentBusiness;
import com.rbu.sms.controller.StudentController;
import com.rbu.sms.dao.StudentDao;

public class Main {
	public static void main(String[] args) {
		// P ref=new C();
		ApplicationContext ap = new ClassPathXmlApplicationContext("resources/sms-spring.xml");

		StudentController controller = (StudentController) ap.getBean("c");
		System.out.println(controller);
		StudentBusiness business = (StudentBusiness) ap.getBean("b");
		System.out.println(business);
		StudentDao dao = (StudentDao) ap.getBean("d");
		System.out.println(dao);
		System.out.println("===============================================");
		StudentController controller1 = (StudentController) ap.getBean("c");
		System.out.println(controller1);
		StudentBusiness business1 = (StudentBusiness) ap.getBean("b");
		System.out.println(business1);
		StudentDao dao1 = (StudentDao) ap.getBean("d");
		System.out.println(dao1);

		System.out.println("===============================================");
		StudentController controller2 = (StudentController) ap.getBean("c");
		System.out.println(controller2);
		StudentBusiness business2 = (StudentBusiness) ap.getBean("b");
		System.out.println(business2);
		StudentDao dao2 = (StudentDao) ap.getBean("d");
		System.out.println(dao2);
	}
}
