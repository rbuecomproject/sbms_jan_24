package ioc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.rbu.sms.controller.StudentController;

public class JdbcMain {
public static void main(String[] args) {
	
	ApplicationContext ap=new ClassPathXmlApplicationContext("resources/sms-spring.xml");
	StudentController stdController=ap.getBean(StudentController.class);
	try {
		stdController.postStudent(1, "vasu", "vasu@gmail.com", "HYD");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
	
}
}
