package com.rbu.sms.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBCon {
	private String drivername;// DI1
	private String url;// DI2
	private String username;// DI3
	private String password;// DI4

	public void setDrivername(String drivername) {
		System.out.println("DI1 drivername injected");
		this.drivername = drivername;
	}

	public void setUrl(String url) {
		System.out.println("DI2 url injected");
		this.url = url;
	}

	public void setUsername(String username) {
		System.out.println("DI3 username injected");
		this.username = username;
	}

	public void setPassword(String password) {
		System.out.println("DI4 password injected");
		this.password = password;
	}

	private Connection connection;

	public Connection getConnection() throws Exception {
		System.out.println("getConnection...");
		if (connection == null) {
			Class.forName(drivername);
			connection = DriverManager.getConnection(url, username, password);
		}
		return connection;
	}
}
