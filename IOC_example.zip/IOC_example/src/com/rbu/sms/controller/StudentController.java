package com.rbu.sms.controller;

import com.rbu.sms.business.StudentBusiness;

public class StudentController {
	private StudentBusiness business;//DI7
	
	public void setBusiness(StudentBusiness business) {
		System.out.println("StudentBusiness injected");
		this.business = business;
	}
	public void postStudent(int id,String name,String email,String address) throws Exception {
		business.createStd(id, name, email, address);
	}
	
	
	
	public StudentController() {
	System.out.println("StudentController object");
	}

}
