package com.rbu.sms.business;

import com.rbu.sms.dao.StudentDao;

public class StudentBusiness {
	private StudentDao studentDao;// DI6

	public void setStudentDao(StudentDao studentDao) {
		System.out.println("StudentDao injected");
		this.studentDao = studentDao;
	}

	public void createStd(int id, String name, String email, String address) throws Exception {
		studentDao.save(id, name, email, address);
	}

	public StudentBusiness() {
		System.out.println("StudentBusiness object");
	}
}
