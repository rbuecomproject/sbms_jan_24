package com.rbu.sms.dao;

import java.sql.Connection;
import java.sql.Statement;

import com.rbu.sms.util.DBCon;

public class StudentDao {
	private DBCon dbcon;//DI5
	
	public void setDbcon(DBCon dbcon) {
		System.out.println("setDbcon con injected");
		this.dbcon = dbcon;
	}
	
	public void save(int id,String name,String email,String address) throws Exception {
		Connection con=dbcon.getConnection();
		Statement statement=con.createStatement();
		statement.executeUpdate("insert into STUDENT values("+id+",'"+name+"','"+email+"','"+address+"')");
		statement.close();
	}
	
	
	
	
	
	
	
	
	
	
	
	public StudentDao() {
		System.out.println("StudentDao object");
	}
	
	
	
}
