package com.rbu.rta.admin;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RequestMapping("/rta-ts/")
@RestController
public class RtaController {
	@Value("${rta.ts-ms.TS}")
	private String stateCode;
	@Value("${IND}")
	private String countrycode;
	@Value("${server.port}")
	private String port;
	@GetMapping("/printcodes")
	public String printcodes() {
		
		return "Country=" + countrycode + ",statecode=" + stateCode+" on port="+port;
	}
	@GetMapping("/getStatecode")
	public String getStatecode() {
		return "statecode=" + stateCode+" on port="+port;
	}
	@GetMapping("/getCountryCode")
	public String getCountryCode() {
		return "Country=" + countrycode+" on port="+port;
	}

}
