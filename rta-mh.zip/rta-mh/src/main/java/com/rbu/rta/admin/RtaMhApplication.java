package com.rbu.rta.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RtaMhApplication {

	public static void main(String[] args) {
		SpringApplication.run(RtaMhApplication.class, args);
	}

}
