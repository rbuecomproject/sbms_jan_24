package com.rbu.thymeleaf.com.rbu.thymeleaf;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

public class ThymeleafApp {

    public static void main(String[] args) {
        // Create a template resolver
        ClassLoaderTemplateResolver templateResolver = new ClassLoaderTemplateResolver();
        templateResolver.setTemplateMode("HTML");

        // Create a template engine
        TemplateEngine templateEngine = new TemplateEngine();
        templateEngine.setTemplateResolver(templateResolver);

        // Create a context with variables
        Context context = new Context();
        context.setVariable("name", "John Doe");

        // Process the template
        String html = templateEngine.process("templates/welcome.html", context);
        System.out.println(html);
    }
}
