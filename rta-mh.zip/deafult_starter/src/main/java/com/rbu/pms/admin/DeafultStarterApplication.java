package com.rbu.pms.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class DeafultStarterApplication {

	public static void main(String[] args) {
		
		ApplicationContext ap = SpringApplication.run(DeafultStarterApplication.class, args);

		String[] beansname = ap.getBeanDefinitionNames();

//		for (String name : beansname) {
//			System.out.println(name);
//		}

		
		
		
	}

}
