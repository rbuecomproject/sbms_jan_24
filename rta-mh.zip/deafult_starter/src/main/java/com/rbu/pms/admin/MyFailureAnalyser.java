package com.rbu.pms.admin;

import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
import org.springframework.boot.diagnostics.FailureAnalysis;

public class MyFailureAnalyser extends AbstractFailureAnalyzer<Throwable> {
	@Override
	protected FailureAnalysis analyze(Throwable rootFailure, Throwable cause) {
		System.out.println("My own error messages");
		return null;
	}

}
