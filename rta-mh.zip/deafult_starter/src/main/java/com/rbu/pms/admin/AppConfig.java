package com.rbu.pms.admin;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
//@PropertySource("classpath:resources/application.properties")

public class AppConfig {
	Logger logger = LoggerFactory.getLogger(AppConfig.class);

	@Value("${com.appname.configurl}")
	private String urlValue;

	@Bean
	public Date createDate() {
		logger.info("createDate method started executon");
		logger.debug("debug message");
		logger.warn("warn message");
		logger.error("error message");
		logger.trace("trace message");
		System.out.println(urlValue);
		logger.info("createDate method completed executon");
		return new Date();
	}

}
