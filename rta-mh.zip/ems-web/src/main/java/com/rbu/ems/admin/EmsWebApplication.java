package com.rbu.ems.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmsWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmsWebApplication.class, args);
	}

}
