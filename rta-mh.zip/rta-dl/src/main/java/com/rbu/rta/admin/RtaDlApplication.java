package com.rbu.rta.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RtaDlApplication {

	public static void main(String[] args) {
		SpringApplication.run(RtaDlApplication.class, args);
	}

}
