package com.rbu.rta.admin;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RtaController {
	@Value("${DL}")
	private String stateCode;
	@Value("${IND}")
	private String countrycode;

	@GetMapping("/printcodes")
	public String printcodes() {
		return "Country=" + countrycode + ",statecode=" + stateCode;
	}

}
