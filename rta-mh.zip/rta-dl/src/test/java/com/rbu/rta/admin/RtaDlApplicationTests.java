package com.rbu.rta.admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RtaDlApplicationTests {

	@Test
	void contextLoads() {
	}

}
