package com.rbu.sms;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringMain 
{
public static void main(String[] args) {
	ApplicationContext ap=new ClassPathXmlApplicationContext("resources/spring.xml");
	
	Student std1=(Student)ap.getBean("std");
	std1.printName();
	Student std2=(Student)ap.getBean("std");
	std2.printName();
	Student std3=(Student)ap.getBean("std");
	std3.printName();
	Student std4=(Student)ap.getBean("std");
	std4.printName();
}
}
