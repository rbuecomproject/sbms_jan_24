package com.rbu.sms;

public class Employee {
public Employee() {
System.out.println("Employee object created...");
}
}
