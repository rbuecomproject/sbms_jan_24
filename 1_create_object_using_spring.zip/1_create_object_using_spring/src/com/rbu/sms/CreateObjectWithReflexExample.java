package com.rbu.sms;

public class CreateObjectWithReflexExample 
{
	
	public static void main(String[] args) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
		//new Student(); //hardcode   CDMA
		
		Class.forName(args[0]).newInstance(); //dynamic approach GSM
		
		
	}

}
