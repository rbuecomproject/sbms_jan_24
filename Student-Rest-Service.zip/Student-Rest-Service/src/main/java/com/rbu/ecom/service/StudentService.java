package com.rbu.ecom.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.rbu.ecom.dto.StudentDTO;
import com.rbu.ecom.entity.Student;
import com.rbu.ecom.repo.StudentRepo;

@Service
public class StudentService implements StudentServiceInterface {
	private final StudentRepo studentRepo;

	public StudentService(StudentRepo studentRepo) {
		this.studentRepo = studentRepo;
	}

	@Override
	public StudentDTO create(StudentDTO dto) {
		Student student = new Student(null, dto.getName(), dto.getEmail(), dto.getAddress());
		student = studentRepo.save(student);
		dto.setId(student.getId());
		return dto;
	}

	@Override
	public StudentDTO update(StudentDTO dto) throws UserNotFoundException {
		if (studentRepo.existsById(dto.getId())) {
			Student student = new Student(dto.getId(), dto.getName(), dto.getEmail(), dto.getAddress());
			student = studentRepo.save(student);
			dto.setId(student.getId());
			return dto;
		}
		throw new UserNotFoundException("record not available please check");
	}

	@Override
	public void delete(Long id) throws UserNotFoundException {
		if (studentRepo.existsById(id)) {
			Student student = new Student();
			student.setId(id);
			studentRepo.delete(student);
		} else {
			throw new UserNotFoundException("record not available please check");
		}

	}

	@Override
	public StudentDTO findOne(Long id) throws UserNotFoundException {
		if (studentRepo.existsById(id)) {
			Optional<Student> studentOpt = studentRepo.findById(id);
			Student student = studentOpt.get();
			StudentDTO dto = new StudentDTO(student.getId(), student.getName(), student.getEmail(),
					student.getAddress());
			return dto;

		}
		throw new UserNotFoundException("record not available please check");
	}

	@Override
	public List<StudentDTO> findAll() {
		List<Student> list = studentRepo.findAll();
		List<StudentDTO> dtoList = new ArrayList<StudentDTO>();
		for (Student std : list) {
			StudentDTO dto = new StudentDTO(std.getId(), std.getName(), std.getEmail(), std.getAddress());
			dtoList.add(dto);
		}
		return dtoList;
	}

}
