package com.rbu.ecom.service;

import java.util.List;

import com.rbu.ecom.dto.StudentDTO;

public interface StudentServiceInterface {
public StudentDTO create(StudentDTO dto);
public StudentDTO update(StudentDTO dto)throws UserNotFoundException ;
public void delete(Long id)throws UserNotFoundException ;
public StudentDTO findOne(Long id)throws UserNotFoundException ;
public List<StudentDTO> findAll();
}
