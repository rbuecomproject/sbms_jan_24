package com.rbu.ecom.rest;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rbu.ecom.dto.StudentDTO;
import com.rbu.ecom.service.StudentServiceInterface;
import com.rbu.ecom.service.UserNotFoundException;

@RestController
@RequestMapping("/student")
public class StudentRestController {
	private final StudentServiceInterface serviceInterface;

	public StudentRestController(StudentServiceInterface serviceInterface) {
		this.serviceInterface = serviceInterface;
	}

	@PostMapping
	public ResponseEntity<StudentDTO> createStudent(@RequestBody StudentDTO dto) {
		dto = serviceInterface.create(dto);
		return new ResponseEntity<StudentDTO>(dto, HttpStatus.CREATED);
	}

	@PutMapping
	public ResponseEntity<StudentDTO> updateStudent(@RequestBody StudentDTO dto) throws UserNotFoundException {
		dto = serviceInterface.update(dto);
		return new ResponseEntity<StudentDTO>(dto, HttpStatus.ACCEPTED);
	}

	// ex: localhost:9090/student/1
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteStudent(@PathVariable Long id) throws UserNotFoundException {
		serviceInterface.delete(id);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<StudentDTO> findOneStudent(@PathVariable Long id) throws UserNotFoundException {
		return new ResponseEntity<StudentDTO>(serviceInterface.findOne(id), HttpStatus.OK);
	}

	@GetMapping
	public ResponseEntity<List<StudentDTO>> findAllStudent() throws UserNotFoundException {
		return new ResponseEntity<List<StudentDTO>>(serviceInterface.findAll(), HttpStatus.OK);
	}
}
