package com.rbu.pms.manager;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class ManagerController {

	public ManagerController() {
		System.out.println("ManagerController object created......");
	}

}
