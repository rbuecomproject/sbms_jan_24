package com.rbu.pms.admin.util;

import org.springframework.stereotype.Component;

@Component
public class AppValidation {
	public AppValidation() {
		System.out.println("AppValidation object created.......");
	}


}
