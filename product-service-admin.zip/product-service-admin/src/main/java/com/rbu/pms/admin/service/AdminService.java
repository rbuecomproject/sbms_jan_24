package com.rbu.pms.admin.service;

import org.springframework.stereotype.Service;

@Service
public class AdminService {

	public AdminService() {
		System.out.println("AdminService  object created...");
	}

}
