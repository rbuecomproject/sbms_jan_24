package com.rbu.pms.admin.config;

import java.util.Date;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	public AppConfig() {
		System.out.println("AppConfig object created.......");
	}

	@Bean
	public Date createDT() {
		System.out.println("Date created...");
		return new Date();
	}

}
