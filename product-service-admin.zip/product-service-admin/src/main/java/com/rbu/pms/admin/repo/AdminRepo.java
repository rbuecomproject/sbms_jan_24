package com.rbu.pms.admin.repo;

import org.springframework.stereotype.Repository;

@Repository
public class AdminRepo {

	public AdminRepo() {
		System.out.println("AdminRepo  object created...");
	}

}
