package com.rbu.pms.admin.web;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminController {

	public AdminController() {
		System.out.println("AdminController object created...");
	}

}
