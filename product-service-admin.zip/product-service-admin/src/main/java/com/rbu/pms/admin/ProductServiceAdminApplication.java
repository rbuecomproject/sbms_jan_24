package com.rbu.pms.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*
 * 
 * @SpringBootConfiguration
@EnableAutoConfiguration
@ComponentScan(excludeFilters={@Filter(type=CUSTOM, classes={TypeExcludeFilter.class}), @Filter(type=CUSTOM, classes={AutoConfigurationExcludeFilter.class})})
 * 
 */

@SpringBootApplication(scanBasePackages = {"com.rbu.pms.*"})
public class ProductServiceAdminApplication {

	public static void main(String[] args) {
		
		//ApplicationContext ap=new ClassPathXmlApplicationContext("xml");
		
		SpringApplication.run(ProductServiceAdminApplication.class, args);
		//it starts IOC  ApplicationContext
		//if it is web  WebApplicationContext
		//component scan will be performed ? which package's it scan  <context:cs b-p="com.rbu.xyz.*"/>
		// it will perform component scan on current package and its child's packages only
		
	}

}
