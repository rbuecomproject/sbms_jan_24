package test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;

import org.apache.tomcat.dbcp.dbcp.BasicDataSource;

public class CPInsert {
	public static void main(String[] args) {
		try {
			BasicDataSource dataSource = new BasicDataSource();
			dataSource.setDriverClassName("oracle.jdbc.OracleDriver");
			dataSource.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
			dataSource.setUsername("system");
			dataSource.setPassword("admin");
			dataSource.setMaxActive(20);
			dataSource.setMaxWait(500);
			System.out.println("IN"+new Date());
			for (int i = 0; i < 10000; i++) {
				// get con from pool
				Connection con = dataSource.getConnection();
				Statement statement = con.createStatement();
				statement
						.executeUpdate("insert into SPRING_STUDENT_2024 values(2,'sravani','sravani@gmail.com','HYD')");
				statement.close();
				// return connection to pool
				con.close();
			}
			System.out.println("COMPLETE:"+new Date());
			dataSource.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		

	}
//ALTER SYSTEM SET processes=20 SCOPE=SPFILE; for connections
}
