package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class JdbcInsert {
	public static void main(String[] args) {
		try {
			for (int i = 0; i < 2000; i++) {
				// load driver
				Class.forName("oracle.jdbc.OracleDriver");
				// get connection
				Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");

				// insert

				Statement statement = con.createStatement();
				statement
						.executeUpdate("insert into SPRING_STUDENT_2024 values(2,'sravani','sravani@gmail.com','HYD')");

				// select
				ResultSet rs = statement.executeQuery("select * from SPRING_STUDENT_2024");
				while (rs.next()) {
					System.out.println("ID:" + rs.getInt(1));
					System.out.println("NAME:" + rs.getString(2));
					System.out.println("Email:" + rs.getString(3));
					System.out.println("Address:" + rs.getString(4));
				}

				// close connection
				con.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
