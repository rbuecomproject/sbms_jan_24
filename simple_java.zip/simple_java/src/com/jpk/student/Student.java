package com.jpk.student;
class Student
{
String name;

Student(){
	
}

}