package main;

public class Employee {
	public Employee() {
		System.out.println("Employee object");
	}

	private String employeeName;
	private int employeeCode;
	private int employeeDepart;
	private int employeeSalary;

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public int getEmployeeCode() {
		return employeeCode;
	}

	public void setEmployeeCode(int employeeCode) {
		this.employeeCode = employeeCode;
	}

	public int getEmployeeDepart() {
		return employeeDepart;
	}

	public void setEmployeeDepart(int employeeDepart) {
		this.employeeDepart = employeeDepart;
	}

	public int getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(int employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

}