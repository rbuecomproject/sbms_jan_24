package main;
public class Test{

int id ;
String name;

public Test() {
System.out.println("Test object");
}

}