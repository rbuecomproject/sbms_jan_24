package main;

public class MainClass {
public static void main(String[] args) {
	//Employee emp=new Employee();  static object
	try {
	Class.forName(args[0]).newInstance();
	}catch (Exception e) {
		System.out.println("wrong entry");
	}
}
}
