package main;
public class Teacher
{
public Teacher() {
System.out.println("Teacher object");
}
}