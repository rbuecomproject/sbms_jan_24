package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.Employee;
import beans.Student;

public class IOCMain {
	public static void main(String[] args) {
		ApplicationContext ap = new ClassPathXmlApplicationContext("resources/sms-spring.xml");
		Student std= (Student) ap.getBean("std");
		System.out.println(std);
	}
}
