package beans;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Employee {
private String name;//d1
private int age;//d2
private String[] courses;//d3=new string[]{"spring","hibernate"};
private int[] fees;//d4
private List<String> fruits;//d5
private Set<String> cricketers;//d6
private Map<String,String> stateCap;//d7 map.put("TS","HYD");

public Employee(String name, int age, String[] courses, int[] fees, List<String> fruits, Set<String> cricketers,
		Map<String, String> stateCap) {
	super();
	System.out.println("Employee 7 param constructor");
	this.name = name;
	this.age = age;
	this.courses = courses;
	this.fees = fees;
	this.fruits = fruits;
	this.cricketers = cricketers;
	this.stateCap = stateCap;
}







@Override
public String toString() {
	return "Employee [name=" + name + ", age=" + age + ", courses=" + Arrays.toString(courses) + ", fees="
			+ Arrays.toString(fees) + ", fruits=" + fruits + ", cricketers=" + cricketers + ", stateCap=" + stateCap
			+ "]";
}







}
