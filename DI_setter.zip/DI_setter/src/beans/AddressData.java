package beans;

public interface AddressData {
	

}
