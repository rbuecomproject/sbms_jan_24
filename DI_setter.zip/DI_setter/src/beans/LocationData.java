package beans;

public class LocationData  implements AddressData {
	private String street;
	private String city;
	private String state;
	private String pin;
	private String road;
	private String landmark;
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getRoad() {
		return road;
	}
	public void setRoad(String road) {
		this.road = road;
	}
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	@Override
	public String toString() {
		return "LocationData [street=" + street + ", city=" + city + ", state=" + state + ", pin=" + pin + ", road="
				+ road + ", landmark=" + landmark + "]";
	}
	
	

}
