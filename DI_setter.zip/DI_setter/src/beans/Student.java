package beans;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
//Phone
public class Student {
private String name;//d1
private int age;//d2
private String[] courses;//d3=new string[]{"spring","hibernate"};
private int[] fees;//d4
private List<String> fruits;//d5
private Set<String> cricketers;//d6
private Map<String,String> stateCap;//d7 map.put("TS","HYD");
private AddressData address;//d8

public void setAddress(AddressData address) {
	System.out.println("setAddress...");
	this.address = address;
}
public void setName(String name) {
	System.out.println("setName");
	this.name = name;
}
public void setAge(int age) {
	System.out.println("setAge");
	this.age = age;
}
public void setCourses(String[] courses) {
	System.out.println("setCourses");
	this.courses = courses;
}
public void setFees(int[] fees) {
	System.out.println("setFees");
	this.fees = fees;
}
public void setFruits(List<String> fruits) {
	System.out.println("setFruits");
	this.fruits = fruits;
}
public void setCricketers(Set<String> cricketers) {
	System.out.println("setCricketers");
	this.cricketers = cricketers;
}
public void setStateCap(Map<String, String> stateCap) {
	System.out.println("setStateCap");
	this.stateCap = stateCap;
}
@Override
public String toString() {
	return "Student [name=" + name + ", age=" + age + ", courses=" + Arrays.toString(courses) + ", fees="
			+ Arrays.toString(fees) + ", fruits=" + fruits + ", cricketers=" + cricketers + ", stateCap=" + stateCap
			+ ", address=" + address + "]";
}







}
