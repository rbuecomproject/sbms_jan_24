package com.rbu.ems.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.rbu.ems.model.Employee;

public class RegServlet extends HttpServlet {
	ApplicationContext ap;

	public RegServlet() {
		System.out.println("tomcat creates...RegServlet after that we are starting IOC container");
		ap = new ClassPathXmlApplicationContext("resources/spring.xml");

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// read data from front end
		PrintWriter out = resp.getWriter();
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String address = req.getParameter("address");
		int salary=Integer.parseInt(req.getParameter("salary"));
	
		Employee employee=new Employee();
		employee.setName(name);
		employee.setEmail(email);
		employee.setAddress(address);
		employee.setSalary(salary);
											//Conf
		//Employee(emp)=>Controller=>Service=>Dao=>Session.save(emp)=>Table
		
		EmployeeController empController=ap.getBean(EmployeeController.class);
		employee=empController.post(employee);
		out.println("Employee with ID="+employee.getId()+",created sucecssfully");
		
		out.flush();
		out.close();

	}
}
