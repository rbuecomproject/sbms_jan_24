package com.rbu.ems.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.rbu.ems.model.Employee;
import com.rbu.ems.service.EmployeeService;

@Controller
public class EmployeeController {
	@Autowired
	EmployeeService employeeService;

	public Employee post(Employee employee) {
		return employeeService.createEmp(employee);
	}

}
