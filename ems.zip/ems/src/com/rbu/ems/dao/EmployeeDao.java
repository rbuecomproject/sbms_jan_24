package com.rbu.ems.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.rbu.ems.model.Employee;

@Repository
public class EmployeeDao {
@Autowired
SessionFactory sessionFactory;

public Employee saveEmp(Employee employee) {
	Session session =sessionFactory.openSession();
	Transaction transaction= session.beginTransaction();
	transaction.begin();
	int id=(int) session.save(employee);
	transaction.commit();
	session.close();
	employee.setId(id);
	return employee;
}
public Employee updateEmp(Employee employee) {
	Session session =sessionFactory.openSession();
	session.update(employee);
	session.close();
	return employee;
}
public void deleteEmp(Employee employee) {
	Session session =sessionFactory.openSession();
	session.delete(employee);
	session.close();
	return;
}

public Employee selectOneEmp(int id) {
	Session session =sessionFactory.openSession();
	Employee emp=(Employee) session.get(Employee.class,id);
	session.close();
	return emp;
}


public List<Employee> selectAllEmp() {
	Session session =sessionFactory.openSession();
		Query q = session.createQuery("from Employee");
		List<Employee> list=q.list();
	session.close();
	return list;
}

}
