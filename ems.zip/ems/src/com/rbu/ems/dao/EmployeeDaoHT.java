package com.rbu.ems.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.rbu.ems.model.Employee;

@Repository
public class EmployeeDaoHT {
	@Autowired
	HibernateTemplate hibernateTemplate;

	public Employee saveEmp(Employee employee) {
		int id = (int) hibernateTemplate.save(employee);
		employee.setId(id);
		return employee;
	}

	public Employee updateEmp(Employee employee) {
		hibernateTemplate.update(employee);
		return employee;
	}

	public void deleteEmp(Employee employee) {
		hibernateTemplate.delete(employee);
		return;
	}

	public Employee selectOneEmp(int id) {
		Employee emp = (Employee) hibernateTemplate.get(Employee.class, id);
		return emp;
	}

	public List<Employee> selectAllEmp() {
		List<Employee> list = hibernateTemplate.find("from Employee");
		return list;
	}

}
