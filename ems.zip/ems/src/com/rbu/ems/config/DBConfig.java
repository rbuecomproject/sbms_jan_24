package com.rbu.ems.config;

import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.hibernate3.HibernateTemplate;

@Configuration
public class DBConfig {
//this configuration class need to provide SessionFactory we should autowire this into all DAO

	@Bean//only one time during IOC start
	public SessionFactory createSessionFactory() {
		org.hibernate.cfg.Configuration cfg=new org.hibernate.cfg.Configuration();
		cfg.configure("resources/oracle.cfg.xml");
		SessionFactory sessionFactory=cfg.buildSessionFactory();
		
	return sessionFactory;
	}
	
	@Bean//only one time during IOC start
	public HibernateTemplate createHt() {
		HibernateTemplate hibernateTemplate=new HibernateTemplate(createSessionFactory());
	return hibernateTemplate;
	}
	
	
	
	
}
