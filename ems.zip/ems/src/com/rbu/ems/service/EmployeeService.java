package com.rbu.ems.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rbu.ems.dao.EmployeeDaoHT;
import com.rbu.ems.model.Employee;

@Service
public class EmployeeService {
	@Autowired
	//EmployeeDao dao;
	EmployeeDaoHT dao;
	
	public Employee createEmp(Employee employee) {
		dao.updateEmp(employee);
		return dao.saveEmp(employee);
	}

}
