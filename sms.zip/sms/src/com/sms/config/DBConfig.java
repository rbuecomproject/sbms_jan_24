package com.sms.config;

import java.beans.PropertyVetoException;

import javax.sql.DataSource;

import org.apache.tomcat.dbcp.dbcp.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

@Configuration
public class DBConfig {
	public DBConfig() {
		System.out.println("DBConfig object created by IOC");
	}

//CP:  apache: DataSource(I)-> BasicDataSource, c3p0: CombopooledDataSource, HikariDataSource,etc....

	@Bean
	public DataSource createDS() throws PropertyVetoException {
		BasicDataSource dataSource = new BasicDataSource();
		 dataSource.setDriverClassName("oracle.jdbc.OracleDriver");
		//dataSource.setDriverClass("com.mysql.jdbc.Driver");
		dataSource.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
		//dataSource.setJdbcUrl("jdbc:mysql://localhost:3306/adminapp?useSSL=false");
		 dataSource.setUsername("system");
		//dataSource.setUsername("root");
		 dataSource.setPassword("admin");
		//dataSource.setPassword("root");
		dataSource.setMaxActive(20);
		dataSource.setMinIdle(2000);
		System.out.println("DataSource object created by IOC");
		return dataSource;

	}

//	@Bean
//	public JdbcTemplate createJT() throws PropertyVetoException {
//	JdbcTemplate jt=new JdbcTemplate();
//	jt.setDataSource(createDS());
//	return jt;
//	}

	@Bean
	public NamedParameterJdbcTemplate createNPJT() throws PropertyVetoException {
		NamedParameterJdbcTemplate npjt = new NamedParameterJdbcTemplate(createDS());
		return npjt;
	}

}
