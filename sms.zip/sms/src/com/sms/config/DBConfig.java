package com.sms.config;

import javax.sql.DataSource;

import org.apache.tomcat.dbcp.dbcp.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class DBConfig {
	public DBConfig() {
	System.out.println("DBConfig object created by IOC");
	}

//CP:  apache: DataSource(I)-> BasicDataSource, c3p0: CombopooledDataSource, HikariDataSource,etc....

	@Bean
	public DataSource createDS() {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setDriverClassName("oracle.jdbc.OracleDriver");
		dataSource.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
		dataSource.setUsername("system");
		dataSource.setPassword("admin");
		dataSource.setMaxActive(20);
		dataSource.setMaxWait(500);
		System.out.println("DataSource object created by IOC");
		return dataSource;

	}
	
	@Bean
	public JdbcTemplate createJT() {
	JdbcTemplate jt=new JdbcTemplate();
	jt.setDataSource(createDS());
	return jt;
	}

}
