package com.sms.web;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.sms.dao.Student;
import com.sms.service.StudentService;

@Controller
public class StudentController {
	@Autowired
	StudentService service;

	public StudentController() {
		System.out.println("StudentController object created by IOC");
	}

	public int post(String name, String email, String address) {
		int id = service.createStudent(name, email, address);
		return id;
	}

	public void put(String name, String email, String address, int id) {
		service.updateStudent(name, email, address, id);
	}
	public void delete(int id) {
		service.deleteStudent(id);
	}

	public Map getStudentIntoMap(int id) {
		return service.selectStudentIntoMap(id);
	}

	public Student getStudentIntoStudent(int id) {
		return service.selectStudentIntoStudent(id);
	}

	public List<Student> gettAll() {
		return service.selectAll();
	}

}
