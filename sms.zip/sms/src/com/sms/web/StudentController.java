package com.sms.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.sms.service.StudentService;

@Controller
public class StudentController {
	@Autowired
	StudentService service;
	
	public StudentController() {
		System.out.println("StudentController object created by IOC");	}

	public int post(String name, String email, String address) {
		int id = service.createStudent(name, email, address);
		return id;
	}

}
