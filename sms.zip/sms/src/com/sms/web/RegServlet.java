package com.sms.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//frontview connect to this class
public class RegServlet extends HttpServlet {
	ApplicationContext ap;

	public RegServlet() {
		System.out.println("tomcat creates...RegServlet after that we are starting IOC container");
		ap = new ClassPathXmlApplicationContext("resources/spring.xml");

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// read data from front end
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String address = req.getParameter("address");
		System.out.println(name);
		System.out.println(email);
		System.out.println(address);

		StudentController controller = ap.getBean(StudentController.class);
		int id = controller.post(name, email, address);

		// Spring intigration
		PrintWriter out = resp.getWriter();
		out.print("<pre>" + "ID: " + id+ "</br>"+ "NAME: " + name + "</br>" + "EMAIL:" + email + "</br>" + "ADDRESS:" + address + "</br>"
				+ " </pre>");
	}
}
