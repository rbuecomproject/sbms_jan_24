package com.sms.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sms.dao.Student;

//frontview connect to this class
public class RegServlet extends HttpServlet {
	ApplicationContext ap;

	public RegServlet() {
		System.out.println("tomcat creates...RegServlet after that we are starting IOC container");
		ap = new ClassPathXmlApplicationContext("resources/spring.xml");

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// read data from front end
		PrintWriter out = resp.getWriter();
		StudentController controller = ap.getBean(StudentController.class);
		String method = req.getParameter("method");
		if (method.equals("Register")) {
			String name = req.getParameter("name");
			String email = req.getParameter("email");
			String address = req.getParameter("address");
			System.out.println(name);
			System.out.println(email);
			System.out.println(address);
			int id = controller.post(name, email, address);

			// Spring intigration
			out.print("<pre>" + "ID: " + id + "</br>" + "NAME: " + name + "</br>" + "EMAIL:" + email + "</br>"
					+ "ADDRESS:" + address + "</br>" + " </pre>");
		}

		else if (method.equals("Update")) {
			int id = Integer.parseInt(req.getParameter("id"));
			String name = req.getParameter("name");
			String email = req.getParameter("email");
			String address = req.getParameter("address");
			System.out.println(name);
			System.out.println(email);
			System.out.println(address);
			controller.put(name, email, address, id);

			// Spring intigration
			out.print("update success </br>" + "<pre>" + "ID: " + id + "</br>" + "NAME: " + name + "</br>" + "EMAIL:"
					+ email + "</br>" + "ADDRESS:" + address + "</br>" + " </pre>");
		}

		else if (method.equals("Delete")) {
			int id = Integer.parseInt(req.getParameter("id"));
			controller.delete(id);
			out.print("delete success");
		}

		else if (method.equals("SelectInMap")) {
			int id = Integer.parseInt(req.getParameter("id"));
			Map map = controller.getStudentIntoMap(id);
			out.print("ID:" + map.get("ID") + "</br>");
			out.print("NAME:" + map.get("NAME") + "</br>");
			out.print("EMAIL:" + map.get("EMAIL") + "</br>");
			out.print("ADDRESS:" + map.get("ADDRESS") + "</br>");
		}

		else if (method.equals("SelectInStudent")) {
			int id = Integer.parseInt(req.getParameter("id"));
			Student student = controller.getStudentIntoStudent(id);
			out.print("ID:" + student.getId() + "</br>");
			out.print("NAME:" + student.getName() + "</br>");
			out.print("EMAIL:" + student.getEmail() + "</br>");
			out.print("ADDRESS:" + student.getAddress() + "</br>");
		} else if (method.equals("All")) {
			List<Student> liststudent = controller.gettAll();
			out.print("<table border='1'>");
			out.print("<tr><td>ID</td><td>NAME</td><td>EMAIL</td><td>ADDRESS</td></tr>");
			for (Student student : liststudent) {
				out.print("<tr>");
				out.print("<td>" + student.getId() + "</td>");
				out.print("<td>" + student.getName() + "</td>");
				out.print("<td>" + student.getEmail() + "</td>");
				out.print("<td>" + student.getAddress() + "</td>");
				out.print("</tr>");
			}
			out.print("</table>");
		}
		out.flush();
		out.close();

	}
}
