package com.sms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sms.dao.StudentRegDaoJT;

@Service
public class StudentService {
	@Autowired
	//StudentRegDao dao;
	StudentRegDaoJT dao;
	
	public StudentService() {
		System.out.println("StudentService object created by IOC");
	}

	public int createStudent(String name, String email, String address) {
		int id = dao.savewithseq(name, email, address);
		return id;
	}
}
