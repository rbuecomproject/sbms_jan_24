package com.sms.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sms.dao.Student;
import com.sms.dao.StudentRegDaoNPJT;

@Service
public class StudentService {
	@Autowired
	// StudentRegDao dao;
	//StudentRegDaoJT dao;
	StudentRegDaoNPJT dao;

	public StudentService() {
		System.out.println("StudentService object created by IOC");
	}

	public int createStudent(String name, String email, String address) {
		int id = dao.savewithseq(name, email, address);
		return id;
	}

	public void updateStudent(String name, String email, String address, int id) {
		dao.update(name, email, address, id);
	}

	public void deleteStudent(int id) {
		dao.delete(id);
	}

	public Map selectStudentIntoMap(int id) {
		return dao.selectOneInMap(id);
	}

	public Student selectStudentIntoStudent(int id) {
		return dao.selectOneInStudent(id);
	}

	public List<Student> selectAll() {
		return dao.selectAllStudent();
	}
}
