//package com.sms.dao;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Map;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public class StudentRegDaoJT {
//	@Autowired
//	JdbcTemplate jdbcTemplate;
//
//	public StudentRegDaoJT() {
//		System.out.println("StudentRegDao object created by IOC");
//	}
//
//	// primary key violation issue when many execute at a time
//	public int save(String name, String email, String address) {
//		int id = jdbcTemplate.queryForInt("select max(id) from RBU_EXPERTS");
//		id++;
//		jdbcTemplate
//				.update("insert into RBU_EXPERTS values(" + id + ",'" + name + "','" + email + "','" + address + "')");
//		return id;
//
//	}
//
//	// using seq to avoid duplicate selection of max(id)
//	public int savewithseq(String name, String email, String address) {
//		int id = jdbcTemplate.queryForInt("SELECT rbu_seq.NEXTVAL FROM DUAL");
//		// jdbcTemplate.update("insert into RBU_EXPERTS values(" + id + ",'" + name +
//		// "','" + email + "','" + address + "')");
//		jdbcTemplate.update("insert into RBU_EXPERTS values(?,?,?,?", new Object[] { id, name, email, address });
//		return id;
//	}
//
//	public void update(String name, String email, String address, int id) {
//		jdbcTemplate.update("update RBU_EXPERTS set name=?,email=?,address=? where id=?",
//				new Object[] { name, email, address, id });
//		return;
//	}
//
//	public void delete(int id) {
//		jdbcTemplate.update("delete RBU_EXPERTS where id=?", new Object[] { id });
//		return;
//	}
//
//	public Map selectOneInMap(int id) {
//		Map map = jdbcTemplate.queryForMap("select * from RBU_EXPERTS where id=?", new Object[] { id });
//		return map;
//	}
//
//	public Student selectOneInStudent(int id) {
//		Student student = (Student) jdbcTemplate.queryForObject("select * from RBU_EXPERTS where id=?",
//				new Object[] { id }, new StudentRowMapper());
//		return student;
//	}
//
//	public List<Student> selectAllStudent() {
//		List list = jdbcTemplate.queryForList("select * from RBU_EXPERTS");
//		List<Student> studentList = new ArrayList<Student>();
//		for (Object obj : list) {
//			Map map = (Map) obj;
//			int id = (int) map.get("ID");
//			String name = (String) map.get("NAME");
//			String email = (String) map.get("EMAIL");
//			String address = (String) map.get("ADDRESS");
//			Student student = new Student();
//			student.setId(id);
//			student.setName(name);
//			student.setEmail(email);
//			student.setAddress(address);
//			studentList.add(student);
//		}
//		return studentList;
//	}
//
//}
////CREATE table RBU_EXPERTS(id number primary key,name varchar2(500),email varchar2(500),address varchar2(500));