package com.sms.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class StudentRegDaoJT {
	@Autowired
	JdbcTemplate jdbcTemplate;

	public StudentRegDaoJT() {
		System.out.println("StudentRegDao object created by IOC");
	}
	//primary key violation issue when many execute at a time
	
	public int save(String name, String email, String address) {
		int id = jdbcTemplate.queryForInt("select max(id) from RBU_EXPERTS");
		id++;
		jdbcTemplate
				.update("insert into RBU_EXPERTS values(" + id + ",'" + name + "','" + email + "','" + address + "')");
		return id;

	}
	public int savewithseq(String name, String email, String address) {
		int id = jdbcTemplate.queryForInt("SELECT rbu_seq.NEXTVAL FROM DUAL");
		jdbcTemplate
				.update("insert into RBU_EXPERTS values(" + id + ",'" + name + "','" + email + "','" + address + "')");
		return id;
	}

}
//CREATE table RBU_EXPERTS(id number primary key,name varchar2(500),email varchar2(500),address varchar2(500));