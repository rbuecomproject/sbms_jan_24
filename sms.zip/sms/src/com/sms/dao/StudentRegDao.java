//package com.sms.dao;
//
//import java.sql.Connection;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Statement;
//
//import javax.sql.DataSource;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public class StudentRegDao {
//	@Autowired
//	DataSource dataSource;
//
//	public StudentRegDao() {
//		System.out.println("StudentRegDao object created by IOC");
//	}
//	public int save(String name, String email, String address) {
//		// plain jdbc not recommended
//
//		try {
//			Connection con = dataSource.getConnection();
//			Statement statement = con.createStatement();
//			ResultSet rs = statement.executeQuery("select max(id) from RBU_EXPERTS");
//			int id = 0;
//			if (rs.next()) {
//				id = rs.getInt(1);
//				id++;
//			}
//			statement.executeUpdate(
//					"insert into RBU_EXPERTS values(" + id + ",'" + name + "','" + email + "','" + address + "')");
//
//			rs.close();
//			statement.close();
//			con.close();
//			return id;
//		} catch (SQLException e) {
//			e.printStackTrace();
//			return 0;
//		}
//
//	}
//
//}
////CREATE table RBU_EXPERTS(id number primary key,name varchar2(500),email varchar2(500),address varchar2(500));