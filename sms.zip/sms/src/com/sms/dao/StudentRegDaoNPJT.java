package com.sms.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class StudentRegDaoNPJT {
	@Autowired
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	public StudentRegDaoNPJT() {
		System.out.println("StudentRegDaoNPJT object created by IOC");
	}

	// primary key violation issue when many execute at a time
	public int save(String name, String email, String address) {
		Map map = new HashMap();
		int id = namedParameterJdbcTemplate.queryForInt("select max(id) from RBU_EXPERTS", map);
		id++;
		map.put("id", id);
		map.put("name", name);
		map.put("email", email);
		map.put("address", address);
		namedParameterJdbcTemplate.update("insert into RBU_EXPERTS values(:id,:name,:email,:address)", map);
		return id;

	}

	// using seq to avoid duplicate selection of max(id)
	public int savewithseq(String name, String email, String address) {
		Map map = new HashMap();
		int id = namedParameterJdbcTemplate.queryForInt("SELECT rbu_seq.NEXTVAL FROM DUAL", map);
		// jdbcTemplate.update("insert into RBU_EXPERTS values(" + id + ",'" + name +
		// "','" + email + "','" + address + "')");

		map.put("id", id);
		map.put("name", name);
		map.put("email", email);
		map.put("address", address);
		namedParameterJdbcTemplate.update("insert into RBU_EXPERTS values(:id,:name,:email,:address)", map);

		return id;
	}

	public void update(String name, String email, String address, int id) {
		Map map = new HashMap();
		map.put("id", id);
		map.put("name", name);
		map.put("email", email);
		map.put("address", address);
		namedParameterJdbcTemplate
				.update("update RBU_EXPERTS set name=:name,email=:email,address=:address where id=:id", map);
		return;
	}

	public void delete(int id) {
		Map map = new HashMap();
		map.put("id", id);
		namedParameterJdbcTemplate.update("delete RBU_EXPERTS where id=:id",map);
		return;
	}

	public Map selectOneInMap(int id) {
		Map inputmap = new HashMap();
		inputmap.put("id", id);
		Map map = namedParameterJdbcTemplate.queryForMap("select * from RBU_EXPERTS where id=:id",inputmap);
		return map;
	}

	public Student selectOneInStudent(int id) {
		Map inputmap = new HashMap();
		inputmap.put("id", id);
		Student student = (Student) namedParameterJdbcTemplate.queryForObject("select * from RBU_EXPERTS where id=:id",
		inputmap, new StudentRowMapper());
		return student;
	}

	public List<Student> selectAllStudent() {
		List list = namedParameterJdbcTemplate.queryForList("select * from RBU_EXPERTS",new HashMap());
		List<Student> studentList = new ArrayList<Student>();
		for (Object obj : list) {
			Map map = (Map) obj;
			BigDecimal id= (BigDecimal) map.get("ID");
			String name = (String) map.get("NAME");
			String email = (String) map.get("EMAIL");
			String address = (String) map.get("ADDRESS");
			Student student = new Student();
			student.setId(id.intValue());
			student.setName(name);
			student.setEmail(email);
			student.setAddress(address);
			studentList.add(student);
		}
		return studentList;
	}

}
//CREATE table RBU_EXPERTS(id number primary key,name varchar2(500),email varchar2(500),address varchar2(500));