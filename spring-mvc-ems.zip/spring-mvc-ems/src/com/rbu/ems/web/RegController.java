package com.rbu.ems.web;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.rbu.ems.model.Employee;
import com.rbu.ems.service.RegService;

@Controller
public class RegController {
	@Autowired
	RegService regService;

	@RequestMapping(value = "/reg.rbu", method = RequestMethod.POST)
	public ModelAndView createEmployee(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String address = req.getParameter("address");
		int salary = Integer.parseInt(req.getParameter("salary"));

		Employee employee = new Employee();
		employee.setName(name);
		employee.setEmail(email);
		employee.setAddress(address);
		employee.setSalary(salary);

		int id = regService.createEmployee(employee);
		Map map = new HashMap();
		map.put("id", id);
		return new ModelAndView("success", map);
	}

}
