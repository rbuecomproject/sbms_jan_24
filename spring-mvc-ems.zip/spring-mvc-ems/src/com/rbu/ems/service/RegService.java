package com.rbu.ems.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rbu.ems.dao.RegDao;
import com.rbu.ems.model.Employee;

@Service
public class RegService {
@Autowired
RegDao dao;
	public int createEmployee(Employee employee) throws Exception {
	return dao.save(employee);
	}
	
}
