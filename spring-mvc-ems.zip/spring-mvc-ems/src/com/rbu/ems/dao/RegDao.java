package com.rbu.ems.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.rbu.ems.model.Employee;

@Repository
public class RegDao {
	@Autowired
	HibernateTemplate hibernateTemplate;

	public int save(Employee employee) throws Exception {
		int id = (int) hibernateTemplate.save(employee);
		return id;
	}

}
