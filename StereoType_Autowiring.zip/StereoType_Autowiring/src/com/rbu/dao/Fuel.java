package com.rbu.dao;

import org.springframework.stereotype.Repository;

@Repository
public class Fuel {
	private String fuelName = "Petrol";

	public Fuel() {
		System.out.println("Fuel object created...");
	}

	public void printFuelName() {
		System.out.println("Fuel =" + fuelName);
	}

}
