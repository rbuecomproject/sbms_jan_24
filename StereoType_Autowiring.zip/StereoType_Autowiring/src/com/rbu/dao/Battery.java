package com.rbu.dao;

import org.springframework.stereotype.Repository;

@Repository
public class Battery {
	private String power = "50kv";

	public Battery() {
		System.out.println("Battery object created...");
	}

	public void connectBattery() {
		System.out.println("Power =" + power);
	}

}
