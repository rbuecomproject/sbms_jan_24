package com.rbu.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rbu.dao.Fuel;

@Service
public class Engine {
	@Autowired
	private Fuel fuel;
	
	
	public Engine() {
	System.out.println("Engine object created..");
	}
	public void startEngine() {
		System.out.println("starting engine...");
		fuel.printFuelName();
	}
}
