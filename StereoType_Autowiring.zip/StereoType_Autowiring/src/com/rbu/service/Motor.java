package com.rbu.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rbu.dao.Battery;

@Service
public class Motor {
	@Autowired
	private Battery battery;

	public Motor() {
		System.out.println("Motor object created...");
	}

	public void startMotor() {
		System.out.println("starting motor ...");
		battery.connectBattery();
	}
}
