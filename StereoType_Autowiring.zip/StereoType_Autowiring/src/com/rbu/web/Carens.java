package com.rbu.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.rbu.service.Engine;

@Controller
public class Carens {
	@Autowired
	private Engine engine;//Engine engine=new Engine();

	public Carens() {
		System.out.println("Carens object created...");
	}

	public void startCar() {
		System.out.println("starting car....");
		engine.startEngine();
	}

}
