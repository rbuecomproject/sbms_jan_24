package com.rbu.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.rbu.service.Motor;

@Controller
public class MGAstorEv {
	@Autowired
	private Motor motor;

	public MGAstorEv() {
		System.out.println("MGAstorEv object created...");
	}

	public void startCar() {
		System.out.println("Starting car...");
		motor.startMotor();
	}
}
