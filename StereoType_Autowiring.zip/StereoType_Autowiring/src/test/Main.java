package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.rbu.web.Carens;
import com.rbu.web.MGAstorEv;

public class Main {
public static void main(String[] args) {
	
	
	ApplicationContext ap=new ClassPathXmlApplicationContext("resources/spring.xml");
	
	Carens car=ap.getBean(Carens.class);

	car.startCar();
	MGAstorEv mgEVcar=ap.getBean(MGAstorEv.class);

	mgEVcar.startCar();
}
}
