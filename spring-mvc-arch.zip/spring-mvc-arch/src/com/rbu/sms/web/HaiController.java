package com.rbu.sms.web;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

public class HaiController implements Controller{
	
	@Override
	public ModelAndView handleRequest(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		String name=req.getParameter("name");
		System.out.println("Hai... to "+name);
		Map<String, String> map=new HashMap<String, String>();
		map.put("msg", "Hai... to "+name);
		ModelAndView mav=new ModelAndView("hai",map);//output data with output page name 
		return mav;
	}

}
